import numpy as np


class ReplayMemory:
    def __init__(self, input_dims, max_mem, batch_size, combined=False):
        pass

    def store_transition(self, state, action, reward, state_, terminal):
        pass

    def sample_memory(self):
        pass

    def is_sufficient(self):
        pass
